import React, { useRef } from "react";
import { Layer, Line, Rect, Stage, Image } from "react-konva";
import useImage from "use-image";
import Rectangle from "./Rectangle";
import { v4 as uuidv4 } from "uuid";
import Circle from "./Circle";

const LionImage = () => {
  const [image] = useImage("tablelayer.jpg");
  return (
    <Image onDragMove={(e)=>{console.log(e)}}
    onDragStart={(e)=>{console.log(e)}}
      boundBoxFunc={(oldBox: any, newBox: any) => {
        console.log(oldBox,newBox)
      }}
      image={image}
      draggable={true}
      width={screen.width}
      alt="11"
      height={screen.height}
    />
  );
};
const scaleBy = 1.01;
const screen = {
  height: 400,
  width: 400,
};
function getDistance(p1: any, p2: any) {
  return Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2));
}

function getCenter(p1: any, p2: any) {
  return {
    x: (p1.x + p2.x) / 2,
    y: (p1.y + p2.y) / 2,
  };
}

function isTouchEnabled() {
  return "ontouchstart" in window || navigator.maxTouchPoints > 0;
}
function per(val: number, total: number) {
  return (100 * val) / total;
}
function perToVal(per: number, total: number) {
  return (total * per) / 100;
}
function Kkk() {
  const stageRef = useRef<any>(null);
  let lastCenter: any = null;
  let lastDist = 0;

  function zoomStage(event: any) {
    event.evt.preventDefault();
    if (stageRef.current !== null) {
      const stage = stageRef.current;
      const oldScale = stage.scaleX();
      const { x: pointerX, y: pointerY } = stage.getPointerPosition();
      const mousePointTo = {
        x: (pointerX - stage.x()) / oldScale,
        y: (pointerY - stage.y()) / oldScale,
      };
      console.log(mousePointTo);
      const newScale =
        event.evt.deltaY > 0 ? oldScale * scaleBy : oldScale / scaleBy;
      stage.scale({ x: newScale, y: newScale });
      const newPos = {
        x: pointerX - mousePointTo.x * newScale,
        y: pointerY - mousePointTo.y * newScale,
      };
      stage.position(newPos);
      stage.batchDraw();
    }
  }

  function handleTouch(e: any) {
    console.log(e)
    e.evt.preventDefault();
    var touch1 = e.evt.touches[0];
    var touch2 = e.evt.touches[1];
    const stage = stageRef.current;
    if (stage !== null) {
      if (touch1 && touch2) {
        if (stage.isDragging()) {
          stage.stopDrag();
        }

        var p1 = {
          x: touch1.clientX,
          y: touch1.clientY,
        };
        var p2 = {
          x: touch2.clientX,
          y: touch2.clientY,
        };

        if (!lastCenter) {
          lastCenter = getCenter(p1, p2);
          return;
        }
        var newCenter = getCenter(p1, p2);

        var dist = getDistance(p1, p2);

        if (!lastDist) {
          lastDist = dist;
        }

        // local coordinates of center point
        var pointTo = {
          x: (newCenter.x - stage.x()) / stage.scaleX(),
          y: (newCenter.y - stage.y()) / stage.scaleX(),
        };

        var scale = stage.scaleX() * (dist / lastDist);

        stage.scaleX(scale);
        stage.scaleY(scale);

        // calculate new position of the stage
        var dx = newCenter.x - lastCenter.x;
        var dy = newCenter.y - lastCenter.y;

        var newPos = {
          x: newCenter.x - pointTo.x * scale + dx,
          y: newCenter.y - pointTo.y * scale + dy,
        };

        stage.position(newPos);
        stage.batchDraw();

        lastDist = dist;
        lastCenter = newCenter;
      }
    }
  }

  function handleTouchEnd() {
    lastCenter = null;
    lastDist = 0;
  }
  const [rectangles, setRectangles] = React.useState<RectangleProperties[]>([]);
  const [circles, setCircles] = React.useState<CircleProperties[]>([]);
  const [selectedId, selectShape] = React.useState<any>(null);
  const [mapState, setMapSate] = React.useState<State>();
  const checkDeselect = (e: any) => {
    // deselect when clicked on empty area
    const clickedOnEmpty = e.target === e.target.getStage();
    if (clickedOnEmpty) {
      selectShape(null);
    }
  };

  const calPercentageOfAll = (data: CommonProperties) => {
    if (data.height) {
      const hp = per(30, 500);
      const wp = per(30, 500);
      const hh = perToVal(hp, data.width);
      const ww = perToVal(wp, data.height);
    }
  };
  const addRectangle = () => {
    const rec = [...rectangles];
    const id = uuidv4();
    const data = screen;
    const hp = per(30, 500);
    const wp = per(30, 500);
    const hh = perToVal(hp, data.width);
    const ww = perToVal(wp, data.height);
    const xp = per(175.0000100708014, 500);
    const yp = per(152.00000866699273, 500);
    const xx = perToVal(xp, data.width);
    const yy = perToVal(yp, data.height);
    rec.push({ fill: "red", height: hh, id, width: ww, x: xx, y: yy });
    setRectangles(rec);
    if (mapState?.markers) {
      const prevState = [...mapState.markers];
      const newState = prevState.concat({
        fill: "red",
        height: hp,
        id: id,
        width: wp,
        x: xp,
        y: yp,
      });
      setMapSate({ markers: newState });
    } else {
      setMapSate({
        markers: [{ fill: "red", height: hp, id: id, width: wp, x: xp, y: yp }],
      });
    }
  };
  const addCircle = () => {
    const cir = [...circles];
    const id = uuidv4();
    const data = screen;
    const rp = per(30, 500);
    const rr = perToVal(rp, data.width);
    const xp = per(175.0000100708014, 500);
    const yp = per(152.00000866699273, 500);
    const xx = perToVal(xp, data.width);
    const yy = perToVal(yp, data.height);
    cir.push({ fill: "red", id, radius: rr, x: xx, y: yy });
    setCircles(cir);
    if (mapState?.markers) {
      const prevState = [...mapState.markers];
      const newState = prevState.concat({
        fill: "red",
        id: id,
        radius: rr,
        x: xp,
        y: yp,
      });
      setMapSate({ markers: newState });
    } else {
      setMapSate({
        markers: [{ fill: "red", id: id, radius: rr, x: xp, y: yp }],
      });
    }
  };

  const updateStateAfterChange = (data: RectangleProperties) => {
    console.log(data);
  };
  const exportVal = () => {
    const val: State = {
      markers: mapState?.markers,
      height: screen.height,
      width: screen.width,
    };
    console.log(val);
  };
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        flexDirection: "row",
      }}
    >
      <div
        style={{ display: "flex", justifyContent: "center", marginTop: "8%" }}
      >
        <Stage
          width={screen.width}
          height={screen.height}
        //   draggable={!isTouchEnabled()}
          onWheel={zoomStage}
          onTouchMove={handleTouch}
          onTouchEnd={handleTouchEnd}
          ref={stageRef}
          onMouseDown={checkDeselect}
          onTouchStart={checkDeselect}
          
        >
          <Layer>
            <LionImage />
            <Circle x={200} y={100} radius={200 / 10} fill="green" />
            {rectangles.map((rect, i) => {
              return (
                <Rectangle
                  key={i}
                  shapeProps={rect}
                  isSelected={rect.id === selectedId}
                  onSelect={() => {
                    selectShape(rect.id);
                  }}
                  onChange={(newAttrs: any) => {
                    const rects = rectangles.slice();
                    rects[i] = newAttrs;
                    updateStateAfterChange(newAttrs);
                    setRectangles(rects);
                  }}
                />
              );
            })}
            {circles.map((rect, i) => {
              return (
                <Circle
                  key={i}
                  shapeProps={rect}
                  isSelected={rect.id === selectedId}
                  onSelect={() => {
                    selectShape(rect.id);
                  }}
                  onChange={(newAttrs: any) => {
                    const rects = circles.slice();
                    rects[i] = newAttrs;
                    updateStateAfterChange(newAttrs);
                    setCircles(rects);
                  }}
                />
              );
            })}
          </Layer>
          <Layer name="top-layer" />
        </Stage>
      </div>
      <div>
        <button onClick={addRectangle}>Add Rectangle</button>
        <button onClick={addCircle}>Add Circle</button>
        <button onClick={exportVal}>Save</button>
      </div>
    </div>
  );
}

export default Kkk;

interface RectangleProperties {
  x: number;
  y: number;
  height: number;
  width: number;
  fill: string;
  id: string;
}
interface CircleProperties {
  x: number;
  y: number;
  radius: number;
  fill: string;
  id: string;
}
interface State {
  height?: number;
  width?: number;
  markers?: (RectangleProperties | CircleProperties)[];
}
interface CommonProperties {
  radius: number;
  height: number;
  width: number;
}
